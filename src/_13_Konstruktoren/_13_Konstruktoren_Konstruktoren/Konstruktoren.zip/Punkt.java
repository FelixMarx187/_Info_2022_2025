package _13_Konstruktoren._13_Konstruktoren_Konstruktoren;

public class Punkt {
    public int x;
    public int y;

    public Punkt(){ //Default Konstruktor
        x = 0;
        y = 0;
    }

    public Punkt(int pX, int pY) { //Konstruktor
        x = pX;
        y = pY;
    }
}
