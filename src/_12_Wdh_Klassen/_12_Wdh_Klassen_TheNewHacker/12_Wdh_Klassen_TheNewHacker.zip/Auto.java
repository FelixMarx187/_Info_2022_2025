package _12_Wdh_Klassen_TheNewHacker;

public class Auto {
    public String modell;
    public String hersteller;
    //public String kennzeichen; //Kennzeichen ist ebenfalls unnötig
    public int ps;
}
