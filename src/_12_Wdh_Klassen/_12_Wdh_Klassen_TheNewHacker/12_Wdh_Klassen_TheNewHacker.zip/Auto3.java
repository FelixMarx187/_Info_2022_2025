package _12_Wdh_Klassen_TheNewHacker;

public class Auto3 {
    /* Brauch man net
    public String modell;
    public String hersteller;
    public String kennzeichen;
    public int ps;
     */
}
