package _13_Konstruktoren._13_Konstruktoren_Konstruktoren;

public class Gerade {
    public Punkt p1;
    public Punkt p2;
}
